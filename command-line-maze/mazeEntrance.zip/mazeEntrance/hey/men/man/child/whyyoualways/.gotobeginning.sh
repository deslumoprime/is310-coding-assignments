#!/bin/bash

cd ..
cd ..
cd ..
cd ..
cd ..
clear
pwd