#!/bin/bash

cd hey
cd men
cd man
cd child
cd whyyoualways
clear 
pwd